import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:mg_common_game/systems/systems.dart';
import 'package:mg_common_game/systems/progression/achievement_manager.dart';
import 'package:mg_common_game/systems/quests/daily_quest.dart';
import 'package:get_it/get_it.dart';
import 'package:provider/provider.dart';
import 'package:mg_common_game/core/audio/audio_manager.dart';
import 'package:mg_common_game/core/ui/theme/app_colors.dart';
import 'package:mg_common_game/systems/progression/upgrade_manager.dart';
import 'core/game_state.dart';
import 'core/managers/save_manager.dart';
import 'core/managers/mini_game_manager.dart';
import 'core/managers/progress_manager.dart';
import 'core/managers/reward_manager.dart';
import 'ui/main_menu_screen.dart';
import 'screens/daily_quest_screen.dart';
import 'screens/achievement_screen.dart';
import 'package:mg_common_game/systems/progression/prestige_manager.dart';
import 'screens/battlepass_screen.dart';
import 'screens/gacha_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _setupDI();
  await GetIt.I<AudioManager>().initialize();

  // Load saved state
  final saveManager = GetIt.I<SaveManager>();
  final initialState = await saveManager.loadGameState() ?? GameState();

  // Load saved upgrade levels
  final upgradeManager = GetIt.I<UpgradeManager>();
  await upgradeManager.loadUpgrades();

  // Apply upgrade effects to RewardManager
  _applyUpgradeEffects(upgradeManager);

  runApp(MonsterPartyApp(initialState: initialState));
}

Future<void> _setupDI() async {
  final di = GetIt.I;

  // Core services
  if (!di.isRegistered<AudioManager>()) {
    di.registerSingleton<AudioManager>(AudioManager());
  }
  if (!di.isRegistered<SaveManager>()) {
    di.registerSingleton<SaveManager>(SaveManager());
  }

  // Hub managers
  if (!di.isRegistered<MiniGameManager>()) {
    di.registerSingleton<MiniGameManager>(MiniGameManager());
  }
  if (!di.isRegistered<ProgressManager>()) {
    di.registerSingleton<ProgressManager>(ProgressManager());
  }
  if (!di.isRegistered<RewardManager>()) {
    di.registerSingleton<RewardManager>(RewardManager());
  }

  // Upgrade system
  if (!di.isRegistered<UpgradeManager>()) {
    di.registerSingleton<UpgradeManager>(UpgradeManager());
  // DailyQuest 시스템
  GetIt.I.registerSingleton(DailyQuestManager());
  // Achievement 시스템
  GetIt.I.registerSingleton(AchievementManager());

  // Prestige 시스템 (mg_common_game)
  if (!GetIt.I.isRegistered<PrestigeManager>()) {
    final prestigeManager = PrestigeManager();
    GetIt.I.registerSingleton(prestigeManager);
  // Collection 시스템
  if (!GetIt.I.isRegistered<CollectionManager>()) {
    GetIt.I.registerSingleton(CollectionManager());
    _registerCollections();
  }
    _setupPrestige(prestigeManager);
    await prestigeManager.loadPrestigeData();
  }
  _registerAchievements();
  _registerDailyQuests();
    _registerUpgrades(di.get<UpgradeManager>());
  }
}

/// Registers 8 upgrades spanning coin boosts, XP multipliers,
/// ticket capacity, and per-minigame performance buffs.
void _registerUpgrades(UpgradeManager manager) {
  manager.registerUpgrade(Upgrade(
    id: 'coin_boost',
    name: 'Coin Boost',
    description: 'Increases coin rewards from all mini-games',
    maxLevel: 10,
    baseCost: 100,
    costMultiplier: 1.5,
    valuePerLevel: 0.1, // +10% per level
  ));

  manager.registerUpgrade(Upgrade(
    id: 'xp_boost',
    name: 'XP Boost',
    description: 'Increases XP rewards from all mini-games',
    maxLevel: 10,
    baseCost: 120,
    costMultiplier: 1.5,
    valuePerLevel: 0.1, // +10% per level
  ));

  manager.registerUpgrade(Upgrade(
    id: 'ticket_capacity',
    name: 'Ticket Pouch',
    description: 'Increases maximum ticket capacity',
    maxLevel: 5,
    baseCost: 200,
    costMultiplier: 2.0,
    valuePerLevel: 1.0, // +1 max ticket per level
  ));

  manager.registerUpgrade(Upgrade(
    id: 'time_extension',
    name: 'Time Extension',
    description: 'Adds bonus seconds to timed mini-games',
    maxLevel: 5,
    baseCost: 150,
    costMultiplier: 1.8,
    valuePerLevel: 2.0, // +2 seconds per level
  ));

  manager.registerUpgrade(Upgrade(
    id: 'score_multiplier',
    name: 'Score Multiplier',
    description: 'Multiplies base score from all games',
    maxLevel: 8,
    baseCost: 250,
    costMultiplier: 1.6,
    valuePerLevel: 0.05, // +5% per level
  ));

  manager.registerUpgrade(Upgrade(
    id: 'monster_xp_rate',
    name: 'Monster Training',
    description: 'Increases monster XP gain rate',
    maxLevel: 10,
    baseCost: 80,
    costMultiplier: 1.4,
    valuePerLevel: 0.15, // +15% per level
  ));

  manager.registerUpgrade(Upgrade(
    id: 'streak_bonus',
    name: 'Streak Power',
    description: 'Increases daily streak bonus rewards',
    maxLevel: 5,
    baseCost: 300,
    costMultiplier: 1.7,
    valuePerLevel: 0.2, // +20% streak bonus per level
  ));

  manager.registerUpgrade(Upgrade(
    id: 'star_threshold',
    name: 'Star Magnet',
    description: 'Lowers score thresholds for earning stars',
    maxLevel: 5,
    baseCost: 400,
    costMultiplier: 2.0,
    valuePerLevel: 0.05, // -5% threshold per level
  ));
}

/// Applies current upgrade levels to runtime managers.
void _applyUpgradeEffects(UpgradeManager upgradeManager) {
  final rewardManager = GetIt.I<RewardManager>();

  final coinBoost = upgradeManager.getUpgrade('coin_boost');
  if (coinBoost != null) {
    rewardManager.setCoinMultiplier(1.0 + coinBoost.currentValue);
  }

  final xpBoost = upgradeManager.getUpgrade('xp_boost');
  if (xpBoost != null) {
    rewardManager.setXpMultiplier(1.0 + xpBoost.currentValue);
  }
}

class MonsterPartyApp extends StatelessWidget {
  final GameState initialState;

  const MonsterPartyApp({super.key, required this.initialState});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => initialState),
        ChangeNotifierProvider.value(value: GetIt.I<MiniGameManager>()),
        ChangeNotifierProvider.value(value: GetIt.I<ProgressManager>()),
        ChangeNotifierProvider.value(value: GetIt.I<RewardManager>()),
        ChangeNotifierProvider.value(value: GetIt.I<UpgradeManager>()),
      ],
      child: MaterialApp(
        title: 'Monster Party',
        theme: ThemeData.dark().copyWith(
          scaffoldBackgroundColor: AppColors.background,
          primaryColor: AppColors.primary,
          colorScheme: ColorScheme.fromSeed(
            seedColor: AppColors.primary,
            brightness: Brightness.dark,
          ),
        ),
        routes: {
          '/daily-quests': (_) => const DailyQuestScreen(),
          '/achievements': (_) => const AchievementScreen(),
          '/daily_quest': (_) => const DailyQuestScreen(),
          '/achievement': (_) => const AchievementScreen(),
          '/battlepass': (_) => const BattlePassScreen(),
          '/gacha': (_) => const GachaScreen(),
        },
        home: const MainMenuScreen(),
      ),
    );
  }
}


void _registerDailyQuests() {
  final dailyQuest = GetIt.I<DailyQuestManager>();
  
  dailyQuest.registerQuest(DailyQuest(
    id: 'collect_gold',
    title: '골드 모으기',
    description: '골드 1000 획득',
    targetValue: 1000,
    goldReward: 500,
    xpReward: 10,
  ));
  
  dailyQuest.registerQuest(DailyQuest(
    id: 'play_games',
    title: '게임 플레이',
    description: '게임 5판 플레이',
    targetValue: 5,
    goldReward: 300,
    xpReward: 5,
  ));
  
  dailyQuest.registerQuest(DailyQuest(
    id: 'level_up',
    title: '레벨업',
    description: '레벨 1 상승',
    targetValue: 1,
    goldReward: 200,
    xpReward: 3,
  ));
}


void _registerAchievements() {
  final achievement = GetIt.I<AchievementManager>();
  
  achievement.registerAchievement(Achievement(
    id: 'gold_1000',
    title: '골드 1000 달성',
    description: '총 골드 1000을 모으세요',
    iconAsset: 'assets/achievements/gold_1000.png',
  ));
  
  achievement.registerAchievement(Achievement(
    id: 'level_10',
    title: '레벨 10 달성',
    description: '레벨 10에 도달하세요',
    iconAsset: 'assets/achievements/level_10.png',
  ));
  
  achievement.registerAchievement(Achievement(
    id: 'play_100',
    title: '100판 플레이',
    description: '게임을 100판 플레이하세요',
    iconAsset: 'assets/achievements/play_100.png',
  ));
}

void _setupPrestige(PrestigeManager manager) {
  // ── Prestige Upgrades (idle game defaults) ──────────────────
  // Five core upgrades for idle games
  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'gold_multiplier',
    name: '골드 배수',
    description: '골드 획득량 +10%',
    maxLevel: 50,
    costPerLevel: 1,
    bonusPerLevel: 0.1,
  ));

  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'xp_boost',
    name: 'XP 부스트',
    description: 'XP 획득량 +15%',
    maxLevel: 40,
    costPerLevel: 2,
    bonusPerLevel: 0.15,
  ));

  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'production_speed',
    name: '생산 속도',
    description: '생산 속도 +20%',
    maxLevel: 30,
    costPerLevel: 2,
    bonusPerLevel: 0.2,
  ));

  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'starting_resources',
    name: '초기 자원',
    description: '초기 자원 +5%',
    maxLevel: 60,
    costPerLevel: 1,
    bonusPerLevel: 0.05,
  ));

  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'offline_income',
    name: '오프라인 수익',
    description: '오프라인 수익 +20%',
    maxLevel: 30,
    costPerLevel: 3,
    bonusPerLevel: 0.2,
  ));

  // ── Prestige Reset Callbacks ────────────────────────────────
  // TODO: Add game-specific reset callbacks:
  // manager.registerResetCallback(() {
  //   if (GetIt.I.isRegistered<ProgressionManager>()) {
  //     GetIt.I<ProgressionManager>().reset();
  //   }
  //   if (GetIt.I.isRegistered<UpgradeManager>()) {
  //     GetIt.I<UpgradeManager>().reset();
  //   }
  // });
}

void _registerCollections() {
  final collection = GetIt.I<CollectionManager>();

  // Characters 컬렉션
  collection.registerCollection(const Collection(
    id: 'characters',
    name: '캐릭터',
    description: '모든 캐릭터를 수집하세요',
    items: [
      CollectionItem(
        id: 'char_warrior',
        name: '전사',
        description: '강인한 근접 전투 캐릭터',
        rarity: CollectionRarity.common,
      ),
      CollectionItem(
        id: 'char_mage',
        name: '마법사',
        description: '강력한 마법 공격 캐릭터',
        rarity: CollectionRarity.rare,
      ),
      CollectionItem(
        id: 'char_archer',
        name: '궁수',
        description: '원거리 정밀 공격 캐릭터',
        rarity: CollectionRarity.rare,
      ),
      CollectionItem(
        id: 'char_assassin',
        name: '암살자',
        description: '치명적인 은신 공격 캐릭터',
        rarity: CollectionRarity.epic,
      ),
      CollectionItem(
        id: 'char_healer',
        name: '힐러',
        description: '팀을 치유하는 지원 캐릭터',
        rarity: CollectionRarity.legendary,
      ),
    ],
    completionReward: CollectionReward(gold: 10000, gems: 500, experience: 2000),
    milestoneRewards: {
      25: CollectionReward(gold: 1000, gems: 50),
      50: CollectionReward(gold: 3000, gems: 150),
      75: CollectionReward(gold: 5000, gems: 300),
    },
  ));

  // 아이템 해제 콜백 (햅틱 피드백)
  collection.onItemUnlocked = (collectionId, itemId) {
    // SettingsManager가 등록되어 있으면 햅틱 피드백
    debugPrint('Collection item unlocked: $collectionId / $itemId');
  };
}
